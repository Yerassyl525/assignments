
using System.Globalization;

namespace Assignment5;

public sealed record DeliveryOrder(string Id, decimal DistanceKm)
{
    public static DeliveryOrder Parse(string? id, string? distanceText)
    {
        if (string.IsNullOrWhiteSpace(id))
            throw new ArgumentException("Order ID is required.");

        if (string.IsNullOrWhiteSpace(distanceText))
            throw new ArgumentException("Distance is required.");

        if (!decimal.TryParse(
                distanceText,
                NumberStyles.Number,
                CultureInfo.InvariantCulture,
                out decimal distance))
        {
            throw new FormatException("Distance must be a valid number.");
        }

        return new DeliveryOrder(id.Trim(), distance);
    }
}