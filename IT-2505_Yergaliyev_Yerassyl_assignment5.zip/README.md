The pipeline processes delivery orders through several stages: validation, filtering, price calculation, sorting, and summary generation.

2.Technologies: C# .NET SDK 9.0 Test framework:xUnit

3.project workflow Input Parsing: Converts text input into a delivery order. Validation and Filtering: Rejects orders with empty IDs or negative distances. Price Calculation: Calculates delivery costs using a selected pricing policy. Sorting: Sorts quotes by cost and then by order ID. Summary Generation: Calculates the total cost and number of rejected orders.

Pricing rules: cost = 500 +100xDistancekm express pricing: cost =800 +150 x distancekm

4.Map and Bind Map transforms a successful value. Bind chains operations that return another Result. If a result contains a failure, subsequent operations are skipped

5.Project structure Program.cs — runs the demonstrations and displays results. DeliveryOrder.cs — defines delivery orders and parses input. DeliveryQuote.cs — defines delivery quotes and summary data. PricingPolicies.cs — contains standard and express pricing functions. DeliveryPipeline.cs — implements validation, filtering, calculation, sorting, and summary generation. Result.cs — implements Result, Map, and Bind. Tests/DeliveryPipelineTests.cs — contains automated tests. Tests/Assignment5.Tests.csproj — test project configuration. assignment5.csproj — main project configuration.

6.how to run

open a new terminal

to check the SDK version: dotnet --version build the project : dotnet build assignment5.csproj run the demonstations: dotnetn run --project assignment5.csproj run the tests: dotnet test Tests/Assignment5.csproj run project:dotnet run

7.demonstations and result Standard pricing => total:3700kzt:1 rejected order express pricing => total :5750 kzt ;1 rejected order empty => total :0kzt invalid numeric input => error missing id order => error map and bind failure => failure is preserved succesfull map => value:10

8.automated t ests: