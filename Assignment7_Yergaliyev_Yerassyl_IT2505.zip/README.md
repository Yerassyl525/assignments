Assignment 7 Description

Assignment 7  Exception Handling in Functional Programming


Project Overview

The application validates delivery-order requests, calculates Standard or Express quotes, reads requests from JSON, and summarizes accepted and rejected orders.
Environment Requirements:
SDK: .NET 9
External runtime packages: None required.
The xUnit test project uses the package versions listed in Tests/Assignment7.Tests.csproj.

Domain Rules

1. Order ID must not be empty.
2. Distance must be a number greater than or equal to zero.
3. Category must be Standard or Express (case-insensitive).
4. Pricing Policies:
	• Standard: 500 + 100 × distanceKm KZT.
	• Express: 800 + 150 × distanceKm KZT.
5. Error Handling:
	• A domain-invalid row is rejected and counted. It does not stop other valid rows in the same file from being processed.
	• A missing input file, unreadable file, malformed JSON, JSON null, or an empty array is treated as a critical workflow failure. In these cases, the application prints an error instead of producing a successful summary.

Data Structures and Outcome Models

Instead of throwing exceptions for expected business logic scenarios, explicit functional types are used to model outcomes:
• Result<T> (in Result.cs): Models a successful outcome Success(value) or a pipeline failure Failure(error). Its constructors are private; instantiation is handled exclusively via Success and Failure factory methods.
• Option<T> (in Option.cs): Models the presence of a value Some(value) or its absence None. Used by DeliveryApplication.FindQuote where a found quote returns Some, while a missing quote returns None, avoiding exceptions or domain failures.
• DeliveryOrderValidation: Represents either a Valid state (carrying an immutable ValidatedDeliveryOrder) or an Invalid state (carrying validation error messages). The validated order constructor is private.

Result Composition (Map and Bind Pipeline)

The core file-processing workflow is implemented in DeliveryApplication.ProcessFile using linear composition:
1. DeliveryFileService.LoadRequests(path) reads and deserializes the JSON file, returning Result<IReadOnlyList<DeliveryOrderRequest>>.
2. Bind(EnsureRequestsExist) checks that the file contains at least one request. If the initial file loading failed, this check is skipped and the underlying failure propagates.
3. Map(DeliveryPipeline.Run) converts a successful request list into a delivery summary. If any preceding step failed, Map is skipped.
4. Program.cs resolves the final success or failure outcome using Result.Match.
Note: Map transforms a successful inner value without modifying the structural shape of the outcome. Bind executes an operation that itself returns a Result, allowing the workflow to fail at a subsequent step. Both combinators propagate earlier failures without invoking their supplied functions. Automated tests verify delegate invocation counts to ensure this short-circuiting behavior.

Exception Boundaries

The DeliveryFileService.LoadRequests method serves as the defensive boundary for infrastructure and parsing anomalies. It must catch:
• FileNotFoundException / DirectoryNotFoundException
• UnauthorizedAccessException
• General IOException instances
• JsonException
These exceptions are caught within the file service layer and mapped directly to a Result.Failure. System exceptions must not leak into the domain pipeline. Domain validation remains explicit, returning Valid or Invalid representations.

Project Structure and Architecture Map

Components are separated into distinct structural files:
• Result.cs — Success/failure model and composition operations (Success, Failure, Map, Bind, Match).
• Option.cs — Missing-value representation (Some, None, Match).
• DeliveryOrder.cs — Validated domain values and explicit validation constraints.
• DeliveryPipeline.cs, PricingPolicies.cs, DeliveryQuote.cs — Pricing calculations and domain processing logic.
• DeliveryFileService.cs — File system interaction and JSON parsing exception boundaries.
• DeliveryApplication.cs — Composed end-to-end application workflow and optional lookup operations.
• Program.cs — Console interface, I/O handling, and diagnostic demonstrations.

Execution and Verification Scenarios


1. Normal Processing Workflow

By default, the application processes SampleData/orders.json.
bash
dotnet build assignment7.csproj
dotnet run --project assignment7.csproj


2. Demonstrating Domain Failures

Following the primary execution loop, the console application manually passes three invalid instances through ValidatedDeliveryOrder.Create to demonstrate business failure handling without crashing:
• Missing order ID
• Negative distance
• Unsupported delivery category

3. Demonstrating Pipeline Failures

When encountering structural or file access errors, the application must print PROCESSING FAILED and execute the failure branch gracefully instead of terminating unexpectedly.
Missing File:
bash
dotnet run --project assignment7.csproj -- SampleData/does-not-exist.json

Malformed Content:
Create a temporary text file named SampleData/bad-orders.json containing invalid data (e.g., not-json), then run:
bash
dotnet run --project assignment7.csproj -- SampleData/bad-orders.json


Automated Testing

Execute the test suite to confirm compliance. The test suite maintains coverage from previous milestones and verifies the functional exception handling behavior:
bash
dotnet test Tests/Assignment7.Tests.csproj

The test scope encompasses:
• Factory initialization successes and rejections.
• Normal quote calculation accuracy.
• Handling of the three distinct domain validation errors.
• Short-circuiting and delegate skipping within Map and Bind.
• Resilience against missing files, malformed JSON, JSON null values, and empty arrays.
• Correct application of Option.Some and Option.None.
