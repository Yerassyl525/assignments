using System.Text.Json;

namespace Assignment5;

public static class DeliveryFileService
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNameCaseInsensitive = true
    };

    public static Result<IReadOnlyList<DeliveryOrderRequest>> LoadRequests(string path)
    {
        if (string.IsNullOrWhiteSpace(path))
            return Result<IReadOnlyList<DeliveryOrderRequest>>.Failure("Input file path is required.");

        try
        {
            var json = File.ReadAllText(path);
            var requests = JsonSerializer.Deserialize<List<DeliveryOrderRequest>>(json, JsonOptions);

            if (requests is null)
                return Result<IReadOnlyList<DeliveryOrderRequest>>.Failure("JSON must contain an array of delivery orders.");

            if (requests.Any(request => request is null))
                return Result<IReadOnlyList<DeliveryOrderRequest>>.Failure("JSON contains a null order entry.");

            return Result<IReadOnlyList<DeliveryOrderRequest>>.Success(requests.AsReadOnly());
        }
        catch (FileNotFoundException)
        {
            return Result<IReadOnlyList<DeliveryOrderRequest>>.Failure($"Input file was not found: {path}");
        }
        catch (DirectoryNotFoundException)
        {
            return Result<IReadOnlyList<DeliveryOrderRequest>>.Failure($"Input directory was not found: {path}");
        }
        catch (UnauthorizedAccessException)
        {
            return Result<IReadOnlyList<DeliveryOrderRequest>>.Failure("Access to the input file was denied.");
        }
        catch (IOException ex)
        {
            return Result<IReadOnlyList<DeliveryOrderRequest>>.Failure($"Could not read input file: {ex.Message}");
        }
        catch (ArgumentException ex)
        {
            return Result<IReadOnlyList<DeliveryOrderRequest>>.Failure($"Invalid input file path: {ex.Message}");
        }
        catch (NotSupportedException ex)
        {
            return Result<IReadOnlyList<DeliveryOrderRequest>>.Failure($"Unsupported input file path: {ex.Message}");
        }
        catch (JsonException ex)
        {
            return Result<IReadOnlyList<DeliveryOrderRequest>>.Failure($"Input JSON is malformed: {ex.Message}");
        }
    }
}
