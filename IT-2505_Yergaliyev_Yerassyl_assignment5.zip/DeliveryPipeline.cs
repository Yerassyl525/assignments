
using System.Collections.ObjectModel;

namespace Assignment5;

public static class DeliveryPipeline
{
    public static IReadOnlyList<DeliveryOrder> SelectValidOrders(
        IReadOnlyList<DeliveryOrder> orders)
    {
        ArgumentNullException.ThrowIfNull(orders);

        var selected = orders
            .Where(order =>
                order is not null &&
                !string.IsNullOrWhiteSpace(order.Id) &&
                order.DistanceKm >= 0)
            .ToArray();

        return Array.AsReadOnly(selected);
    }

    public static IReadOnlyList<DeliveryQuote> CalculateQuotes(
        IReadOnlyList<DeliveryOrder> orders,
        Func<DeliveryOrder, decimal> pricingPolicy)
    {
        ArgumentNullException.ThrowIfNull(orders);
        ArgumentNullException.ThrowIfNull(pricingPolicy);

        var quotes = orders
            .Select(order => new DeliveryQuote(
                order.Id,
                order.DistanceKm,
                pricingPolicy(order)))
            .ToArray();

        return Array.AsReadOnly(quotes);
    }

    public static DeliverySummary CreateSummary(
        IReadOnlyList<DeliveryQuote> quotes,
        int rejectedOrders)
    {
        ArgumentNullException.ThrowIfNull(quotes);

        var orderedQuotes = quotes
            .OrderBy(quote => quote.Cost)
            .ThenBy(quote => quote.OrderId)
            .ToArray();

        var readOnlyQuotes = Array.AsReadOnly(orderedQuotes);

        decimal total = orderedQuotes.Sum(quote => quote.Cost);

        return new DeliverySummary(
            readOnlyQuotes,
            total,
            rejectedOrders);
    }

    public static DeliverySummary Run(
        IReadOnlyList<DeliveryOrder> orders,
        Func<DeliveryOrder, decimal> pricingPolicy)
    {
        ArgumentNullException.ThrowIfNull(orders);
        ArgumentNullException.ThrowIfNull(pricingPolicy);

        var selected = SelectValidOrders(orders);

        var quotes = CalculateQuotes(selected, pricingPolicy);

        return CreateSummary(
            quotes,
            orders.Count - selected.Count);
    }
}