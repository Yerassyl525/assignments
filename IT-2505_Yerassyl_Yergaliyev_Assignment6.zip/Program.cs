using Assignment5;

var requests = new[]
{
    new DeliveryOrderRequest("A", "2", "Standard"),
    new DeliveryOrderRequest("B", "5", "Express"),
    new DeliveryOrderRequest("C", "0", "Standard"),
    new DeliveryOrderRequest("D", "-1", "Standard"),
    new DeliveryOrderRequest("E", "10", "Unknown"),
    new DeliveryOrderRequest("", "3", "Express")
};

var summary = DeliveryPipeline.Run(requests);
Console.WriteLine("DELIVERY SUMMARY");

foreach (var item in summary.Quotes)
{
    Console.WriteLine($"{item.OrderId}: {item.Category}, {item.DistanceKm} km = {item.Cost} KZT");
}

Console.WriteLine($"Total: {summary.TotalCost} KZT");
Console.WriteLine($"Rejected: {summary.RejectedOrders}");

Console.WriteLine("\nVALID FACTORY RESULT");
var valid = ValidatedDeliveryOrder.Create("F", "2", "Standard");
var quote = DeliveryPipeline.CalculateQuote(valid);
Console.WriteLine(quote.IsSuccess ? $"Quote: {quote.Value.Cost} KZT" : quote.Error);

Console.WriteLine("\nINVALID FACTORY RESULT");
var invalid = ValidatedDeliveryOrder.Create("G", "-2", "Unknown");
var invalidQuote = DeliveryPipeline.CalculateQuote(invalid);
Console.WriteLine(invalidQuote.IsFailure ? invalidQuote.Error : invalidQuote.Value.Cost.ToString());

Console.WriteLine("\nMISSING PREREQUISITE");
var missingPrerequisite = DeliveryPipeline.CalculateQuote(
    new DeliveryOrderValidation.Invalid(new[] { "Order has not passed validation." }));
Console.WriteLine(missingPrerequisite.IsFailure ? missingPrerequisite.Error : "Unexpected success");

Console.WriteLine("\nREPEATED CALCULATION");
var first = DeliveryPipeline.CalculateQuote(valid);
var second = DeliveryPipeline.CalculateQuote(valid);
Console.WriteLine($"First: {first.Value.Cost} KZT; second: {second.Value.Cost} KZT; same result: {first.Value == second.Value}");
