using Assignment5;

var inputPath = args.Length > 0
    ? args[0]
    : Path.Combine("SampleData", "orders.json");

Console.WriteLine("DELIVERY FILE WORKFLOW");
var processing = DeliveryApplication.ProcessFile(inputPath);

processing.Match(
    summary =>
    {
        Console.WriteLine($"Loaded and processed orders: {summary.Quotes.Count + summary.RejectedOrders}");
        foreach (var quote in summary.Quotes)
            Console.WriteLine($"{quote.OrderId}: {quote.Category}, {quote.DistanceKm} km = {quote.Cost} KZT");
        Console.WriteLine($"Total: {summary.TotalCost} KZT");
        Console.WriteLine($"Rejected: {summary.RejectedOrders}");

        Console.WriteLine("\nOPTION / MISSING VALUE");
        DeliveryApplication.FindQuote(summary, "A").Match(
            quote => { Console.WriteLine($"Found order A: {quote.Cost} KZT"); return 0; },
            () => { Console.WriteLine("Order A was not found."); return 0; });
        DeliveryApplication.FindQuote(summary, "NOT-FOUND").Match(
            quote => { Console.WriteLine($"Found quote: {quote.Cost} KZT"); return 0; },
            () => { Console.WriteLine("NOT-FOUND is missing; this is not an exception."); return 0; });
        return 0;
    },
    error =>
    {
        Console.WriteLine($"PROCESSING FAILED: {error}");
        return 1;
    });


Console.WriteLine("\nDOMAIN FAILURE DEMONSTRATIONS");
var domainFailures = new[]
{
    (Name: "Missing order ID", Request: new DeliveryOrderRequest("", "2", "Standard")),
    (Name: "Negative distance", Request: new DeliveryOrderRequest("NEG-1", "-1", "Standard")),
    (Name: "Unsupported category", Request: new DeliveryOrderRequest("CAT-1", "2", "Overnight"))
};

foreach (var example in domainFailures)
{
    var validation = ValidatedDeliveryOrder.Create(
        example.Request.Id,
        example.Request.DistanceText,
        example.Request.Category);
    var quoteResult = DeliveryPipeline.CalculateQuote(validation);
    quoteResult.Match(
        quote =>
        {
            Console.WriteLine($"{example.Name}: unexpectedly succeeded with {quote.Cost} KZT");
            return 0;
        },
        error =>
        {
            Console.WriteLine($"{example.Name}: rejected - {error}");
            return 0;
        });
}
