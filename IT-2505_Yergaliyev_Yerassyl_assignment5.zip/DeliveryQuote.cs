using System.Collections.ObjectModel;

namespace Assignment5;

public sealed record DeliveryQuote(
    string OrderId,
    decimal DistanceKm,
    decimal Cost);

public sealed record DeliverySummary(
    ReadOnlyCollection<DeliveryQuote> Quotes,
    decimal TotalCost,
    int RejectedOrders);
