namespace Assignment5;

public static class DeliveryPipeline
{
    public static Result<DeliveryQuote> CalculateQuote(DeliveryOrderValidation validation)
    {
        ArgumentNullException.ThrowIfNull(validation);

        return validation switch
        {
            DeliveryOrderValidation.Valid valid => Result<DeliveryQuote>.Success(CreateQuote(valid.Order)),
            DeliveryOrderValidation.Invalid invalid => Result<DeliveryQuote>.Failure(string.Join(" ", invalid.Errors)),
            _ => Result<DeliveryQuote>.Failure("Unknown delivery validation state.")
        };
    }

    public static DeliverySummary Run(IReadOnlyList<DeliveryOrderRequest> requests)
    {
        ArgumentNullException.ThrowIfNull(requests);

        var quotes = new List<DeliveryQuote>();
        var rejected = 0;

        foreach (var request in requests)
        {
            var validation = ValidatedDeliveryOrder.Create(request.Id, request.DistanceText, request.Category);
            var quoteResult = CalculateQuote(validation);

            switch (quoteResult.IsSuccess)
            {
                case true:
                    quotes.Add(quoteResult.Value);
                    break;
                case false:
                    rejected++;
                    break;
            }
        }

        var orderedQuotes = quotes.OrderBy(item => item.Cost).ThenBy(item => item.OrderId).ToArray();
        return new DeliverySummary(Array.AsReadOnly(orderedQuotes), orderedQuotes.Sum(item => item.Cost), rejected);
    }

    private static DeliveryQuote CreateQuote(ValidatedDeliveryOrder order)
    {
        var cost = order.Category switch
        {
            "standard" => PricingPolicies.Standard(order.DistanceKm),
            "express" => PricingPolicies.Express(order.DistanceKm),
            _ => throw new InvalidOperationException("Validated order has an unsupported category.")
        };

        return new DeliveryQuote(order.Id, order.DistanceKm, order.Category, cost);
    }
}
