A C# console application for validating delivery orders and calculating standard or express delivery quotes. The safe workflow uses an immutable validated order, a factory outcome with distinct Valid and Invalid cases, pattern matching, and pure quote calculation.

 Requirements and rules

 Order ID must not be empty.
 Distance must be a valid decimal number and must be greater than or equal to zero.
 Category must be Standard or Express (case-insensitive).
 Standard price: 500 + 100 × distanceKm KZT.
 Express price: 800 + 150 × distanceKm KZT.
 Zero distance is allowed.
 Repeating quote calculation with the same validated order is safe and returns the same quote. The operation has no shared-state mutation.
  Invalid requests are counted as rejected and do not produce quotes.

 Safe workflow

DeliveryOrderRequest represents untrusted input.

ValidatedDeliveryOrder.Create checks all rules and returns either DeliveryOrderValidation.Valid carrying an immutable validated order, or DeliveryOrderValidation.Invalid carrying error messages.

The constructor of ValidatedDeliveryOrder is private, so callers cannot directly create an unchecked instance.

DeliveryPipeline.CalculateQuote  uses a switch expression to handle Valid and Invalid explicitly. An invalid state returns a failure instead of a quote.

DeliveryPipeline.Run` applies the factory and transition to each request, then sorts successful quotes and creates a summary without mutating the input collection.

 Requirement mapping

- Factory and validation rules: DeliveryOrder.cs, ValidatedDeliveryOrder.Create.
- Distinct cases: DeliveryOrderValidation.Valid and DeliveryOrderValidation.Invalid in DeliveryOrder.cs.
- Pattern matching and safe transition: DeliveryPipeline.cs, CalculateQuote.
- Pure pricing: PricingPolicies.cs.
- Result type and Map/Bind: `Result.cs.
- Demonstrations: Program.cs.
- Automated tests: Tests/DeliveryPipelineTests.cs.

 Demonstrations

Run the console app to see a successful quote, rejected inputs, a missing-prerequisite rejection, and repeated calculation. A successful quote requires the factory to produce Valid; an Invalid outcome is rejected by CalculateQuote. Repeating the same valid calculation returns an equal quote.

 Build, run, and test

Required SDK: .NET 9 SDK.

Run commands from the extracted project root:


dotnet --version
dotnet build assignment5.csproj
dotnet run --project assignment5.csproj
dotnet test Tests/Assignment5.Tests.csproj


 Test coverage

1. Factory success and expected fields.
2. Missing ID rejected.
3. Negative distance rejected.
4. Unknown category rejected.
5. Non-numeric distance rejected.
6. Valid case pattern match and normal quote calculation.
7. Invalid case pattern match and rejection.
8. Missing prerequisite rejected.
9. Repeated calculation returns the same outcome.
10. Zero-distance boundary accepted.
11. Failed transition preserves the original request.
12. Pipeline summary includes correct quotes and rejected count.
13. Map/Bind operations are skipped after failure.

Contribution

Implemented for this stage: validated delivery-order factory, explicit validation cases, pattern-matched quote transition, immutable/pure pricing flow, console demonstrations, automated tests, and this README. If submitting as a team, replace this paragraph with every member's name, group, and specific contribution.