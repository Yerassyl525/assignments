﻿using Assignment5;
using Xunit;

namespace Assignment5.Tests;

public class DeliveryPipelineTests
{
    [Fact]
    public void NormalWorkflow_ProducesExpectedSummary()
    {
        var orders = new[]
        {
            new DeliveryOrder("A", 2),
            new DeliveryOrder("B", 5),
            new DeliveryOrder("C", 0),
            new DeliveryOrder("D", -1)
        };

        var result = DeliveryPipeline.Run(
            orders, PricingPolicies.Standard);

        Assert.Equal(3, result.Quotes.Count);
        Assert.Equal(2200m, result.TotalCost);
        Assert.Equal(1, result.RejectedOrders);
    }

    [Fact]
    public void EmptyDataset_ReturnsEmptySummary()
    {
        var result = DeliveryPipeline.Run(
            Array.Empty<DeliveryOrder>(),
            PricingPolicies.Standard);

        Assert.Empty(result.Quotes);
        Assert.Equal(0m, result.TotalCost);
        Assert.Equal(0, result.RejectedOrders);
    }

    [Fact]
    public void ZeroDistance_IsAccepted()
    {
        var orders = new[]
        {
            new DeliveryOrder("A", 0)
        };

        var result = DeliveryPipeline.Run(
            orders, PricingPolicies.Standard);

        Assert.Single(result.Quotes);
        Assert.Equal(500m, result.Quotes[0].Cost);
    }

    [Fact]
    public void InvalidAndMissingInput_IsRejected()
    {
        Assert.Throws<FormatException>(
            () => DeliveryOrder.Parse("A", "abc"));

        Assert.Throws<ArgumentException>(
            () => DeliveryOrder.Parse("", "2"));

        Assert.Throws<ArgumentException>(
            () => DeliveryOrder.Parse("A", ""));
    }

    [Fact]
    public void TwoPolicies_ProduceDifferentResults()
    {
        var orders = new[]
        {
            new DeliveryOrder("A", 2)
        };

        var standard = DeliveryPipeline.Run(
            orders, PricingPolicies.Standard);

        var express = DeliveryPipeline.Run(
            orders, PricingPolicies.Express);

        Assert.Equal(700m, standard.TotalCost);
        Assert.Equal(1100m, express.TotalCost);
        Assert.NotEqual(standard.TotalCost, express.TotalCost);
    }

    [Fact]
    public void Selection_DoesNotModifyOriginalCollection()
    {
        var orders = new List<DeliveryOrder>
        {
            new("A", 2),
            new("B", -1)
        };

        var original = orders.ToArray();

        var selected = DeliveryPipeline.SelectValidOrders(orders);

        Assert.Equal(original, orders.ToArray());
        Assert.Equal(2, orders.Count);
        Assert.Single(selected);
    }

    [Fact]
    public void NullInput_IsRejected()
    {
        Assert.Throws<ArgumentNullException>(
            () => DeliveryPipeline.Run(
                null!, PricingPolicies.Standard));

        Assert.Throws<ArgumentNullException>(
            () => DeliveryPipeline.CalculateQuotes(
                Array.Empty<DeliveryOrder>(), null!));
    }
[Fact]
public void Map_TransformsSuccessfulValue()
{
    var result = Result<int>.Success(5)
        .Map(value => value * 2);

    Assert.True(result.IsSuccess);
    Assert.Equal(10, result.Value);
}

[Fact]
public void MapAndBind_SkipOperationsAfterFailure()
{
    int operationsExecuted = 0;

    var result = Result<int>.Failure("Invalid order")
        .Map(value =>
        {
            operationsExecuted++;
            return value * 2;
        })
        .Bind(value =>
        {
            operationsExecuted++;
            return Result<string>.Success(value.ToString());
        });

    Assert.True(result.IsFailure);
    Assert.Equal("Invalid order", result.Error);
    Assert.Equal(0, operationsExecuted);
}

}