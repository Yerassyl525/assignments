namespace Assignment5;

public static class PricingPolicies
{
    public static decimal Standard(DeliveryOrder order)
    {
        return 500m + 100m * order.DistanceKm;
    }

    public static decimal Express(DeliveryOrder order)
    {
        return 800m + 150m * order.DistanceKm;
    }
}
