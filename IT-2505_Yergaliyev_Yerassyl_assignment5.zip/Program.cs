
using Assignment5;

var orders = new List<DeliveryOrder>
{
    DeliveryOrder.Parse("A", "2"),
    DeliveryOrder.Parse("B", "5"),
    DeliveryOrder.Parse("C", "0"),
    DeliveryOrder.Parse("D", "-1"),
    DeliveryOrder.Parse("E", "10")
};

ShowResults("STANDARD", DeliveryPipeline.Run(
    orders, PricingPolicies.Standard));

ShowResults("EXPRESS", DeliveryPipeline.Run(
    orders, PricingPolicies.Express));

Console.WriteLine("\nEMPTY DATASET");

var emptyResult = DeliveryPipeline.Run(
    Array.Empty<DeliveryOrder>(),
    PricingPolicies.Standard);

ShowResults("EMPTY", emptyResult);

Console.WriteLine("\nINVALID INPUT");
try
{
    DeliveryOrder.Parse("F", "abc");
}
catch (FormatException ex)
{
    Console.WriteLine(ex.Message);
}

Console.WriteLine("\nMISSING INPUT");

try
{
    DeliveryOrder.Parse("", "2");
}
catch (ArgumentException ex)
{
    Console.WriteLine(ex.Message);
}

Console.WriteLine("\nMAP AND BIND");

int operationsExecuted = 0;

var failedResult = Result<int>.Failure("Invalid order");

var mappedResult = failedResult.Map(value =>
{
operationsExecuted++;
return value * 2;
});

var boundResult = mappedResult.Bind(value =>
{
operationsExecuted++;
return Result<string>.Success($"Order value: {value}");
});

Console.WriteLine($"Success: {boundResult.IsSuccess}");
Console.WriteLine($"Error: {boundResult.Error}");
Console.WriteLine($"Operations executed: {operationsExecuted}");

var successfulResult = Result<int>.Success(5)
.Map(value => value * 2)
.Bind(value => Result<string>.Success($"Value: {value}"));

Console.WriteLine(successfulResult.Value);


static void ShowResults(string policy, DeliverySummary summary)
{
    Console.WriteLine($"\n{policy}");

    foreach (var quote in summary.Quotes)
    {
        Console.WriteLine(
            $"{quote.OrderId}: {quote.DistanceKm} km = {quote.Cost} KZT");
    }

    Console.WriteLine($"Total: {summary.TotalCost} KZT");
    Console.WriteLine($"Rejected: {summary.RejectedOrders}");
}